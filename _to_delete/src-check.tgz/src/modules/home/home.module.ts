import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GuardModule } from '@my/common';
import { HomeService } from './home.service';
import { HomeController } from './home.controller';
import { LessonProgress } from 'src/common/core/entitys/lesson-progress.entity';
import { Lesson } from 'src/common/core/entitys/lesson.entity';
import { Unit } from 'src/common/core/entitys/unit.entity';
import { UserGamification, XpTransaction } from 'src/common/core/entitys/gamification.entity';
import { DailyTracking } from 'src/common/core/entitys/daily-tracking.entity';
import { UserVocabularyProgress } from 'src/common/core/entitys/user-vocabulary-progress.entity';
import { VocabularyRelation } from 'src/common/core/entitys/vocabulary-relation.entity';
import { LessonGatingModule } from 'src/common/services/lesson-gating.module';

@Module({
  imports: [
    GuardModule,
    LessonGatingModule,
    TypeOrmModule.forFeature([
      LessonProgress,
      Lesson,
      Unit,
      UserGamification,
      XpTransaction,
      DailyTracking,
      UserVocabularyProgress,
      VocabularyRelation,
    ]),
  ],
  providers: [HomeService],
  controllers: [HomeController],
})
export class HomeModule {}
