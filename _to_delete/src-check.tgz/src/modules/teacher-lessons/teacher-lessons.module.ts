import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Lesson } from 'src/common/core/entitys/lesson.entity';
import { GrammarContent } from 'src/common/core/entitys/grammar-content.entity';
import { Group } from 'src/common/core/entitys/group.entity';
import { ReadingContent } from 'src/common/core/entitys/reading-content.entity';
import { ListeningContent } from 'src/common/core/entitys/listening-content.entity';
import { ListeningTranscript } from 'src/common/core/entitys/listening-transcript.entity';
import { QuizContent } from 'src/common/core/entitys/quiz-content.entity';
import { Exercise } from 'src/common/core/entitys/exercise.entity';
import { ExerciseItem } from 'src/common/core/entitys/exercise-item.entity';
import { Unit } from 'src/common/core/entitys/unit.entity';
import { TeacherLessonsService } from './teacher-lessons.service';
import { BlocksService } from './blocks.service';
import { TeacherLessonsController } from './teacher-lessons.controller';
import { BlocksController } from './blocks.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Lesson,
      Unit,
      GrammarContent,
      Group,
      ReadingContent,
      ListeningContent,
      ListeningTranscript,
      QuizContent,
      Exercise,
      ExerciseItem,
    ]),
  ],
  providers: [TeacherLessonsService, BlocksService],
  controllers: [TeacherLessonsController, BlocksController],
})
export class TeacherLessonsModule {}
